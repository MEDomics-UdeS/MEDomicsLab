#!/bin/bash
GREEN='\033[0;32m'        # Green
BLUE='\033[0;34m'         # Blue
RED='\033[0;31m'          # Red
NC='\033[0m'              # No Color


# Check if Python 3.10 is installed
echo -e "${BLUE}Checking if Python 3.10 is installed...${NC}"
if command -v python3.10 &> /dev/null
then
    # Python 3.10 is installed
    echo -e "${GREEN}Python 3.10 is installed.${NC}"
else
    # Python 3.10 is not installed
    echo -e "${RED}Python 3.10 is not installed.${NC}"
    # Install Python 3.10
    echo -e "${BLUE}Installing Python 3.10...${NC}"
    sudo apt-get update
    sudo apt-get install python3.10
fi

# Check if python3-virtualenv is installed
echo -e "${BLUE}Checking if python3-virtualenv is installed...${NC}"
if ! command -v python3-virtualenv &> /dev/null
then
    # Install virtualenv
    echo -e "${RED}python3-virtualenv is not installed.${NC}"
    echo -e "${BLUE}Installing virtualenv...${NC}"
    sudo apt-get update
    sudo apt-get install python3-virtualenv
fi

virtualenv --python=/usr/bin/python3.10 venv

# Create a Python 3.10 virtual environment
echo -e "${BLUE}Creating a Python 3.10 virtual environment...${NC}"
python3.10 -m venv venv

# Activate the virtual environment
echo -e "${BLUE}Activating the virtual environment...${NC}"
source venv/bin/activate

# checking versions
echo -e "${BLUE}Checking versions...${NC}"
python3.10 --version
pip3 --version


# Check if pip is installed
echo -e "${BLUE}Checking if pip is installed...${NC}"
if ! command -v pip3 &> /dev/null
then
    # Install pip
    echo -e "${RED}pip is not installed.${NC}"
    echo -e "${BLUE}Installing pip...${NC}"
    sudo apt-get install python3-pip
fi

# upgrade pip
echo -e "${BLUE}Upgrading pip...${NC}"
python3.10 -m pip3 install --upgrade pip3

# Install requirements from file
echo -e "${BLUE}Installing requirements from file...${NC}"
pip3 install -r requirements.txt

# Deactivate the virtual environment
echo -e "${BLUE}Deactivating the virtual environment...${NC}"
deactivate
# Export virtual environment path to MED_ENV variable in ~/.bashrc
echo -e "${BLUE}Exporting virtual environment path to MED_ENV variable in ~/.bashrc...${NC}"
echo 'export MED_ENV="'$(pwd)'/venv"' >> ~/.bashrc
source ~/.bashrc